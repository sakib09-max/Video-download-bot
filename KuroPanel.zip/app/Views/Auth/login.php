<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center pt-5">
    <div class="col-lg-5 col-md-6">
        <?= $this->include('Layout/msgStatus') ?>
        <div class="card shadow-sm mb-5">
            <div class="card-header d-flex align-items-center">
                <i class="bi bi-lock-fill me-2" style="font-size: 1.3rem;"></i>
                <span>Secure Login</span>
            </div>
            <div class="card-body">
                <?= form_open() ?>
                
                <div class="form-group mb-4">
                    <label for="username" class="form-label">
                        <i class="bi bi-person me-2"></i>Username
                    </label>
                    <input type="text" class="form-control" name="username" id="username" aria-describedby="help-username" placeholder="Enter your username" required minlength="4" value="<?= old('username') ?>">
                    <?php if ($validation->hasError('username')) : ?>
                        <small id="help-username" class="form-text text-danger d-block mt-2">
                            <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('username') ?>
                        </small>
                    <?php endif; ?>
                </div>

                <div class="form-group mb-4">
                    <label for="password" class="form-label">
                        <i class="bi bi-key me-2"></i>Password
                    </label>
                    <input type="password" class="form-control" name="password" id="password" aria-describedby="help-password" placeholder="Enter your password" required minlength="3">
                    <?php if ($validation->hasError('password')) : ?>
                        <small id="help-password" class="form-text text-danger d-block mt-2">
                            <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('password') ?>
                        </small>
                    <?php endif; ?>
                </div>

                <div class="form-check mb-4">
                    <input type="checkbox" class="form-check-input" name="stay_log" id="stay_log" value="yes">
                    <label class="form-check-label" for="stay_log" data-bs-toggle="tooltip" data-bs-placement="top" title="Keep session more than 30 minutes">
                        <i class="bi bi-shield-check me-1"></i>Keep me logged in
                    </label>
                </div>

                <div class="form-group mb-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-box-arrow-in-right me-2"></i>Log In
                    </button>
                </div>

                <?= form_close() ?>
            </div>
        </div>

        <div class="text-center">
            <p class="text-muted mb-3">
                <small>Don't have an account yet?</small>
            </p>
            <a href="<?= site_url('register') ?>" class="btn btn-outline-light w-100">
                <i class="bi bi-person-plus me-2"></i>Create Account
            </a>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
