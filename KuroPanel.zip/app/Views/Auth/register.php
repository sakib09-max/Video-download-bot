<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center pt-5">
    <div class="col-lg-5 col-md-6">
        <?= $this->include('Layout/msgStatus') ?>
        <div class="card shadow-sm mb-5">
            <div class="card-header d-flex align-items-center">
                <i class="bi bi-person-plus-fill me-2" style="font-size: 1.3rem;"></i>
                <span>Create Account</span>
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <div class="form-group mb-4">
                    <label for="username" class="form-label">
                        <i class="bi bi-person me-2"></i>Username
                    </label>
                    <input type="text" class="form-control" name="username" id="username" aria-describedby="help-username" placeholder="Choose a username" minlength="4" maxlength="24" value="<?= old('username') ?>" required>
                    <?php if ($validation->hasError('username')) : ?>
                        <small id="help-username" class="form-text text-danger d-block mt-2">
                            <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('username') ?>
                        </small>
                    <?php endif; ?>
                </div>

                <div class="form-group mb-4">
                    <label for="password" class="form-label">
                        <i class="bi bi-key me-2"></i>Password
                    </label>
                    <input type="password" class="form-control" name="password" id="password" aria-describedby="help-password" placeholder="Create a strong password" minlength="3" maxlength="24" required>
                    <?php if ($validation->hasError('password')) : ?>
                        <small id="help-password" class="form-text text-danger d-block mt-2">
                            <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('password') ?>
                        </small>
                    <?php endif; ?>
                </div>

                <div class="form-group mb-4">
                    <label for="password2" class="form-label">
                        <i class="bi bi-key-fill me-2"></i>Confirm Password
                    </label>
                    <input type="password" name="password2" id="password2" class="form-control" placeholder="Confirm your password" aria-describedby="help-password2" minlength="3" maxlength="24" required>
                    <?php if ($validation->hasError('password2')) : ?>
                        <small id="help-password2" class="form-text text-danger d-block mt-2">
                            <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('password2') ?>
                        </small>
                    <?php endif; ?>
                </div>

                <div class="form-group mb-4">
                    <label for="referral" class="form-label">
                        <i class="bi bi-ticket-perforated me-2"></i>Credit Token
                    </label>
                    <input type="text" name="referral" id="referral" class="form-control" placeholder="Enter your credit token" aria-describedby="help-referral" value="<?= old('referral') ?>" maxlength="25" required>
                    <?php if ($validation->hasError('referral')) : ?>
                        <small id="help-referral" class="form-text text-danger d-block mt-2">
                            <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('referral') ?>
                        </small>
                    <?php endif; ?>
                </div>

                <div class="form-group mb-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-person-check me-2"></i>Register
                    </button>
                </div>

                <?= form_close() ?>
            </div>
        </div>

        <div class="text-center">
            <p class="text-muted mb-3">
                <small>Already have an account?</small>
            </p>
            <a href="<?= site_url('login') ?>" class="btn btn-outline-light w-100">
                <i class="bi bi-box-arrow-in-right me-2"></i>Log In
            </a>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
