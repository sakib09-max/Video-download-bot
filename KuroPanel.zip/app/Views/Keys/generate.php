<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-lg-7">
        <?= $this->include('Layout/msgStatus') ?>
        
        <?php if (session()->getFlashdata('user_key')) : ?>
            <div class="alert alert-success fade show mb-4" role="alert">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <small class="text-muted d-block mb-1"><i class="bi bi-controller me-1"></i>Game</small>
                            <strong><?= session()->getFlashdata('game') ?></strong>
                        </div>
                        <div class="mb-3">
                            <small class="text-muted d-block mb-1"><i class="bi bi-hourglass-split me-1"></i>Duration</small>
                            <strong><?= session()->getFlashdata('duration') ?> Days</strong>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <small class="text-muted d-block mb-1"><i class="bi bi-phone me-1"></i>Max Devices</small>
                            <strong><?= session()->getFlashdata('max_devices') ?> Device(s)</strong>
                        </div>
                        <div class="mb-3">
                            <small class="text-muted d-block mb-1"><i class="bi bi-wallet me-1"></i>Credits Used</small>
                            <strong class="text-danger">-<?= session()->getFlashdata('fees') ?></strong>
                        </div>
                    </div>
                </div>
                <div class="mt-3 pt-3 border-top">
                    <small class="text-muted d-block mb-2"><i class="bi bi-key-fill me-1"></i>License Key</small>
                    <div class="input-group">
                        <input type="text" class="form-control key-sensi" value="<?= session()->getFlashdata('user_key') ?>" readonly>
                        <button class="btn btn-outline-light" type="button" onclick="navigator.clipboard.writeText('<?= session()->getFlashdata('user_key') ?>')">
                            <i class="bi bi-clipboard me-1"></i>Copy
                        </button>
                    </div>
                    <small class="text-muted d-block mt-2"><i class="bi bi-info-circle me-1"></i>Duration will start when license login.</small>
                    <small class="text-muted d-block">Total Credits Left: <strong><?= $user->saldo ?></strong></small>
                </div>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between">
                <div>
                    <i class="bi bi-plus-circle-fill me-2" style="font-size: 1.3rem;"></i>
                    <span>Generate New License</span>
                </div>
                <a class="btn btn-sm btn-outline-light" href="<?= site_url('keys') ?>">
                    <i class="bi bi-list-ul me-1"></i>View All
                </a>
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <div class="row">
                    <div class="form-group col-lg-6 mb-4">
                        <label for="game" class="form-label">
                            <i class="bi bi-controller me-1"></i>Game
                        </label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'game', 'id' => 'game'], $game, old('game') ?: '') ?>
                        <?php if ($validation->hasError('game')) : ?>
                            <small class="text-danger d-block mt-2">
                                <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('game') ?>
                            </small>
                        <?php endif; ?>
                    </div>

                    <div class="form-group col-lg-6 mb-4">
                        <label for="max_devices" class="form-label">
                            <i class="bi bi-phone me-1"></i>Max Devices
                        </label>
                        <input type="number" name="max_devices" id="max_devices" class="form-control" placeholder="Enter device limit" value="<?= old('max_devices') ?: 1 ?>" min="1" required>
                        <?php if ($validation->hasError('max_devices')) : ?>
                            <small class="text-danger d-block mt-2">
                                <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('max_devices') ?>
                            </small>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group mb-4">
                    <label for="duration" class="form-label">
                        <i class="bi bi-hourglass-split me-1"></i>Duration (Days)
                    </label>
                    <?= form_dropdown(['class' => 'form-select', 'name' => 'duration', 'id' => 'duration'], $duration, old('duration') ?: '') ?>
                    <?php if ($validation->hasError('duration')) : ?>
                        <small class="text-danger d-block mt-2">
                            <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('duration') ?>
                        </small>
                    <?php endif; ?>
                </div>

                <div class="form-group mb-4">
                    <label for="user_key" class="form-label">
                        <i class="bi bi-key-fill me-1"></i>License Key
                    </label>
                    <input type="text" name="user_key" id="user_key" class="form-control" placeholder="Enter or generate a unique key" required>
                    <?php if ($validation->hasError('user_key')) : ?>
                        <small class="text-danger d-block mt-2">
                            <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('user_key') ?>
                        </small>
                    <?php endif; ?>
                </div>

                <div class="form-group mb-4">
                    <label for="estimation" class="form-label">
                        <i class="bi bi-wallet me-1"></i>Estimated Cost
                    </label>
                    <div class="input-group">
                        <input type="text" id="estimation" class="form-control" placeholder="Your order will total" readonly>
                        <span class="input-group-text">Credits</span>
                    </div>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-lightning-fill me-2"></i>Generate License
                    </button>
                </div>

                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var price = JSON.parse('<?= $price ?>');
        getPrice(price);
        
        // When selected
        $("#max_devices, #duration, #game").change(function() {
            getPrice(price);
        });
        
        // try to get price
        function getPrice(price) {
            var device = $("#max_devices").val();
            var durate = $("#duration").val();
            var gprice = price[durate];
            if (gprice != NaN && device && durate) {
                var result = (device * gprice);
                $("#estimation").val(result);
            } else {
                $("#estimation").val('Estimation error');
            }
        }
    });
</script>
<?= $this->endSection() ?>
