<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<div class="row pb-5 justify-content-center">
    <div class="col-lg-8">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <div class="col-lg-8 mb-3">
        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between">
                <div>
                    <i class="bi bi-pencil-square me-2" style="font-size: 1.3rem;"></i>
                    <span>Edit License Key</span>
                </div>
                <div>
                    <a class="btn btn-sm btn-outline-light me-2" href="<?= site_url('keys/generate') ?>">
                        <i class="bi bi-plus-circle me-1"></i>Create
                    </a>
                    <a class="btn btn-sm btn-outline-light" href="<?= site_url('keys') ?>">
                        <i class="bi bi-list-ul me-1"></i>View All
                    </a>
                </div>
            </div>

            <div class="card-body">
                <?= form_open('keys/edit') ?>

                <div class="row">
                    <input type="hidden" name="id_keys" value="<?= $key->id_keys ?>">

                    <?php if ($user->level == 1) : ?>
                        <div class="col-lg-6 mb-4">
                            <label for="game" class="form-label">
                                <i class="bi bi-controller me-1"></i>Game
                            </label>
                            <input type="text" name="game" id="game" class="form-control" placeholder="Game name" value="<?= old('game') ?: $key->game ?>">
                            <?php if ($validation->hasError('game')) : ?>
                                <small class="text-danger d-block mt-2">
                                    <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('game') ?>
                                </small>
                            <?php endif; ?>
                        </div>

                        <div class="col-lg-6 mb-4">
                            <label for="duration" class="form-label">
                                <i class="bi bi-hourglass-split me-1"></i>Duration (Days)
                            </label>
                            <input type="number" name="duration" id="duration" class="form-control" placeholder="3" value="<?= old('duration') ?: $key->duration ?>">
                            <?php if ($validation->hasError('duration')) : ?>
                                <small class="text-danger d-block mt-2">
                                    <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('duration') ?>
                                </small>
                            <?php endif; ?>
                        </div>

                        <div class="col-lg-6 mb-4">
                            <label for="max_devices" class="form-label">
                                <i class="bi bi-phone me-1"></i>Max Devices
                            </label>
                            <input type="number" name="max_devices" id="max_devices" class="form-control" placeholder="3" value="<?= old('max_devices') ?: $key->max_devices ?>">
                            <?php if ($validation->hasError('max_devices')) : ?>
                                <small class="text-danger d-block mt-2">
                                    <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('max_devices') ?>
                                </small>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <div class="col-lg-6 mb-4">
                        <label for="user_key" class="form-label">
                            <i class="bi bi-key-fill me-1"></i>License Key
                        </label>
                        <input type="text" name="user_key" id="user_key" class="form-control" placeholder="Enter key" value="<?= old('user_key') ?: $key->user_key ?>">
                        <?php if ($validation->hasError('user_key')) : ?>
                            <small class="text-danger d-block mt-2">
                                <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('user_key') ?>
                            </small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="status" class="form-label">
                            <i class="bi bi-toggle-on me-1"></i>Status
                        </label>
                        <?php $sel_status = ['' => '&mdash; Select Status &mdash;', '0' => 'Banned/Blocked', '1' => 'Active',]; ?>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'status', 'id' => 'status'], $sel_status, $key->status) ?>
                        <?php if ($validation->hasError('status')) : ?>
                            <small class="text-danger d-block mt-2">
                                <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('status') ?>
                            </small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="registrator" class="form-label">
                            <i class="bi bi-person me-1"></i>Registrator
                        </label>
                        <input type="text" name="registrator" id="registrator" class="form-control" placeholder="Username" value="<?= old('registrator') ?: $key->registrator ?>">
                        <?php if ($validation->hasError('registrator')) : ?>
                            <small class="text-danger d-block mt-2">
                                <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('registrator') ?>
                            </small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-12 mb-4">
                        <label for="expired_date" class="form-label">
                            <i class="bi bi-calendar-event me-1"></i>Expiration Date
                            <?php if (!$key->expired_date) : ?>
                                <span class="badge badge-warning">Not Started</span>
                            <?php endif; ?>
                        </label>
                        <input type="text" name="expired_date" id="expired_date" class="form-control" placeholder="<?= $time::now() ?>" value="<?= old('expired_date') ?: $key->expired_date ?>">
                        <?php if ($validation->hasError('expired_date')) : ?>
                            <small class="text-danger d-block mt-2">
                                <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('expired_date') ?>
                            </small>
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-12 mb-4">
                        <label for="devices" class="form-label">
                            <i class="bi bi-phone me-1"></i>Registered Devices
                            <span class="badge badge-primary maxDev"><?= $key_info->total ?>/<?= $key->max_devices ?></span>
                            <small class="text-muted">(Separate with Enter)</small>
                        </label>
                        <textarea class="form-control" name="devices" id="devices" rows="<?= ($key_info->total > $key->max_devices) ? 3 : max(3, $key_info->total) ?>"><?= old('devices') ?: ($key_info->total ? $key_info->devices : '') ?></textarea>
                        <?php if ($validation->hasError('devices')) : ?>
                            <small class="text-danger d-block mt-2">
                                <i class="bi bi-exclamation-circle me-1"></i><?= $validation->getError('devices') ?>
                            </small>
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-12">
                        <button class="btn btn-primary btnUpdate me-2">
                            <i class="bi bi-check-circle me-1"></i>Update License
                        </button>
                        <a href="<?= site_url('keys') ?>" class="btn btn-outline-light">
                            <i class="bi bi-x-circle me-1"></i>Cancel
                        </a>
                    </div>

                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var level = "<?= $user->level ?>";
        if (level != 1) {
            $("#registrator, #expired_date, #devices").attr('disabled', true);
        }
        
        $("input, select, textarea").change(function() {
            $(".btnUpdate").attr('disabled', false);
        });
    });

    var total = "<?= $key_info->total ?>";
    $("#max_devices").change(function() {
        $(".maxDev").html(total + '/' + $(this).val());
        $("#devices").attr('rows', $(this).val());
    });
</script>
<?= $this->endSection() ?>
