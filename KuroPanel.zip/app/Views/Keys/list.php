<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<div class="row">
    <div class="col-lg-12">
        <div class="alert alert-primary d-flex align-items-center" role="alert">
            <i class="bi bi-info-circle-fill me-2" style="font-size: 1.2rem;"></i>
            <div>
                <strong>Search Tip:</strong> Find licenses by game name, key, registrator, or status.
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-header d-flex align-items-center justify-content-between">
                <div>
                    <i class="bi bi-key-fill me-2" style="font-size: 1.3rem;"></i>
                    <span>Manage Licenses</span>
                </div>
                <div>
                    <a href="<?= site_url('keys/generate') ?>" class="btn btn-sm btn-primary me-2">
                        <i class="bi bi-plus-circle me-1"></i>Create New
                    </a>
                    <button class="btn btn-sm btn-outline-light" id="blur-out" data-bs-toggle="tooltip" data-bs-placement="top" title="Toggle Key Visibility">
                        <i class="bi bi-eye-slash"></i>
                    </button>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table id="datatable" class="table table-hover" style="width:100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Game</th>
                                <th>License Key</th>
                                <th>Devices</th>
                                <th>Duration</th>
                                <th>Expired</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>

<script>
    $(document).ready(function() {
        var table = $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [[0, "desc"]],
            ajax: "<?= site_url('keys/api') ?>",
            columns: [
                {
                    data: 'id_keys',
                    render: function(data) {
                        return `<span class="badge badge-primary">${data}</span>`;
                    }
                },
                {
                    data: 'game',
                    render: function(data) {
                        return `<strong>${data}</strong>`;
                    }
                },
                {
                    data: 'user_key',
                    render: function(data) {
                        return `<span class="keyBlur key-sensi" style="font-family: monospace;">${data}</span>`;
                    }
                },
                {
                    data: 'devices',
                    render: function(data, type, row) {
                        var totalDevice = (row.devices ? row.devices : 0);
                        return `<span id="devMax-${row.user_key}" class="badge badge-success">${totalDevice}/${row.max_devices}</span>`;
                    }
                },
                {
                    data: 'duration',
                    render: function(data) {
                        return `${data} days`;
                    }
                },
                {
                    data: 'expired',
                    name: 'expired_date',
                    render: function(data) {
                        return data ? `<small>${data}</small>` : '<span class="text-muted">Not Started</span>';
                    }
                },
                {
                    data: 'status',
                    render: function(data) {
                        if (data == 'Active' || data == 1) {
                            return `<span class="badge badge-success"><i class="bi bi-check-circle me-1"></i>Active</span>`;
                        } else {
                            return `<span class="badge badge-danger"><i class="bi bi-x-circle me-1"></i>Blocked</span>`;
                        }
                    }
                },
                {
                    data: null,
                    render: function(data, type, row) {
                        var isActive = (row.status == 'Active' || row.status == 1);
                        var btnBlock = isActive ? 
                            `<button class="btn btn-sm btn-outline-danger" onclick="blockUserKey('${row.user_key}')" title="Block key"><i class="bi bi-lock-fill"></i></button>` :
                            `<button class="btn btn-sm btn-outline-success" onclick="unblockUserKey('${row.user_key}')" title="Unblock key"><i class="bi bi-unlock-fill"></i></button>`;
                        
                        var btnReset = row.devices ? 
                            `<button class="btn btn-sm btn-outline-warning" onclick="resetUserKey('${row.user_key}')" title="Reset devices"><i class="bi bi-arrow-clockwise"></i></button>` :
                            `<button class="btn btn-sm btn-outline-secondary" disabled title="No devices"><i class="bi bi-arrow-clockwise"></i></button>`;
                        
                        var btnEdit = `<a href="${window.location.origin}/keys/edit/${row.id_keys}" class="btn btn-sm btn-primary" title="Edit"><i class="bi bi-pencil"></i></a>`;
                        var btnDelete = `<button class="btn btn-sm btn-outline-danger" onclick="deleteUserKey('${row.user_key}')" title="Delete"><i class="bi bi-trash"></i></button>`;
                        
                        return `<div class="btn-group" role="group">${btnEdit} ${btnBlock} ${btnReset} ${btnDelete}</div>`;
                    }
                }
            ]
        });

        $("#blur-out").click(function() {
            if ($(".keyBlur").hasClass("key-sensi")) {
                $(".keyBlur").removeClass("key-sensi");
                $("#blur-out").html(`<i class="bi bi-eye"></i>`);
            } else {
                $(".keyBlur").addClass("key-sensi");
                $("#blur-out").html(`<i class="bi bi-eye-slash"></i>`);
            }
        });
    });

    function resetUserKey(keys) {
        Swal.fire({
            title: 'Reset Devices?',
            text: "This will clear all registered devices for this key.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#667eea',
            cancelButtonColor: '#ef4444',
            confirmButtonText: 'Yes, Reset'
        }).then((result) => {
            if (result.isConfirmed) {
                var base_url = window.location.origin;
                var api_url = `${base_url}/keys/reset`;
                $.getJSON(api_url, {userkey: keys, reset: 1}, function(data) {
                    if (data.reset) {
                        $(`#devMax-${keys}`).html(`0/${data.devices_max}`);
                        Swal.fire('Success!', 'Devices have been reset.', 'success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        Swal.fire('Error!', data.devices_total ? "Access denied." : "Already reset.", 'error');
                    }
                });
            }
        });
    }
    
    function blockUserKey(keys) {
        Swal.fire({
            title: 'Block Key?',
            text: "This key will be blocked and cannot be used.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#667eea',
            cancelButtonColor: '#ef4444',
            confirmButtonText: 'Yes, Block'
        }).then((result) => {
            if (result.isConfirmed) {
                var base_url = window.location.origin;
                var api_url = `${base_url}/keys/block`;
                $.getJSON(api_url, {userkey: keys, block: 1}, function(data) {
                    if (data.block) {
                        Swal.fire('Blocked!', 'Key has been blocked.', 'success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        Swal.fire('Error!', 'Failed to block key.', 'error');
                    }
                });
            }
        });
    }
    
    function unblockUserKey(keys) {
        Swal.fire({
            title: 'Unblock Key?',
            text: "This key will be activated again.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#667eea',
            cancelButtonColor: '#ef4444',
            confirmButtonText: 'Yes, Unblock'
        }).then((result) => {
            if (result.isConfirmed) {
                var base_url = window.location.origin;
                var api_url = `${base_url}/keys/unblock`;
                $.getJSON(api_url, {userkey: keys, unblock: 1}, function(data) {
                    if (data.unblock) {
                        Swal.fire('Unblocked!', 'Key has been unblocked.', 'success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        Swal.fire('Error!', 'Failed to unblock key.', 'error');
                    }
                });
            }
        });
    }
    
    function deleteUserKey(keys) {
        Swal.fire({
            title: 'Delete Key?',
            text: "This action cannot be undone!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#667eea',
            cancelButtonColor: '#ef4444',
            confirmButtonText: 'Yes, Delete'
        }).then((result) => {
            if (result.isConfirmed) {
                var base_url = window.location.origin;
                var api_url = `${base_url}/keys/delete`;
                $.getJSON(api_url, {userkey: keys, deletec: 1}, function(data) {
                    if (data.deletec) {
                        Swal.fire('Deleted!', 'Key has been deleted.', 'success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        Swal.fire('Error!', 'Failed to delete key.', 'error');
                    }
                });
            }
        });
    }
</script>

<?= $this->endSection() ?>
