<header>
    <nav class="navbar navbar-expand-md navbar-dark shadow-lg align-middle">
        <div class="container-fluid px-4">
            <a class="navbar-brand d-flex align-items-center" href="<?= site_url() ?>">
                <i class="bi bi-lightning-fill me-2" style="font-size: 1.5rem;"></i>
                <span><?= BASE_NAME ?></span>
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <?php if (session()->has('userid')) : ?>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('keys') ?>">
                                <i class="bi bi-key-fill me-1"></i>Manage Keys
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('keys/generate') ?>">
                                <i class="bi bi-plus-circle-fill me-1"></i>Create Keys
                            </a>
                        </li>
                    </ul>
                    <div class="float-right">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-person-circle me-2" style="font-size: 1.3rem;"></i>
                                    <span><?= getName($user) ?></span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg-start text-white" style="background: linear-gradient(135deg, #1e293b, #0f172a); border: 1px solid #334155; border-radius: 12px;" aria-labelledby="navbarDropdown">
                                    <li>
                                        <a class="dropdown-item" href="<?= site_url('settings') ?>" style="color: #f1f5f9; transition: all 0.3s ease;">
                                            <i class="bi bi-gear me-2"></i>Settings
                                        </a>
                                    </li>
                                    <li>
                                        <hr class="dropdown-divider" style="border-color: #334155; margin: 0.5rem 0;">
                                    </li>
                                    <?php if ($user->level == 1) : ?>
                                        <li>
                                            <a class="dropdown-item" href="<?= site_url('admin/manage-users') ?>" style="color: #f1f5f9; transition: all 0.3s ease;">
                                                <i class="bi bi-person-check me-2"></i>Manage Users
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?= site_url('admin/create-referral') ?>" style="color: #f1f5f9; transition: all 0.3s ease;">
                                                <i class="bi bi-person-plus me-2"></i>Create Referral
                                            </a>
                                        </li>
                                        <li>
                                            <hr class="dropdown-divider" style="border-color: #334155; margin: 0.5rem 0;">
                                        </li>
                                    <?php endif; ?>
                                    <li>
                                        <a class="dropdown-item" href="<?= site_url('logout') ?>" style="color: #ef4444; transition: all 0.3s ease;">
                                            <i class="bi bi-box-arrow-right me-2"></i>Logout
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
            </div>
        <?php endif; ?>

        </div>
    </nav>
</header>

<style>
    .dropdown-item:hover {
        background: rgba(102, 126, 234, 0.2) !important;
        color: #667eea !important;
        border-radius: 8px;
        margin: 0 0.5rem;
        padding-left: 1rem;
    }
</style>
