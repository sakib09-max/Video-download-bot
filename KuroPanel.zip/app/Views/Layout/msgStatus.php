<?php if (session()->getFlashdata('msgDanger')) : ?>
    <div class="alert alert-danger fade show d-flex align-items-center" role="alert">
        <i class="bi bi-exclamation-circle-fill me-2" style="font-size: 1.2rem;"></i>
        <div>
            <?= session()->getFlashdata('msgDanger') ?>
        </div>
        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php elseif (session()->getFlashdata('msgSuccess')) : ?>
    <div class="alert alert-success fade show d-flex align-items-center" role="alert">
        <i class="bi bi-check-circle-fill me-2" style="font-size: 1.2rem;"></i>
        <div>
            <?= session()->getFlashdata('msgSuccess') ?>
        </div>
        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php elseif (session()->getFlashdata('msgWarning')) : ?>
    <div class="alert alert-warning fade show d-flex align-items-center" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2" style="font-size: 1.2rem;"></i>
        <div>
            <?= session()->getFlashdata('msgWarning') ?>
        </div>
        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php else : ?>
    <?php if (session()->has('userid')) : ?>
        <?php if (isset($messages)) : ?>
            <div class="alert alert-<?= $messages[1] ?> fade show d-flex align-items-center" role="alert">
                <i class="bi bi-info-circle-fill me-2" style="font-size: 1.2rem;"></i>
                <div>
                    <?= $messages[0] ?>
                </div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php else : ?>
            <div class="alert alert-primary fade show d-flex align-items-center" role="alert">
                <i class="bi bi-hand-thumbs-up-fill me-2" style="font-size: 1.2rem;"></i>
                <div>
                    <strong>Welcome back!</strong> Hello <?= getName($user) ?>, nice to see you here.
                </div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
    <?php else : ?>
        <div class="alert alert-primary alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="bi bi-info-circle-fill me-2" style="font-size: 1.2rem;"></i>
            <div>
                <strong>Welcome!</strong> Good to see you here. Please log in or register to continue.
            </div>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
<?php endif; ?>
